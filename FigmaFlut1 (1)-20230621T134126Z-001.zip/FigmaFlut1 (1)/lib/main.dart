import 'package:flutter/material.dart';
import 'package:flutterapp/figmaflut1app/generatedita1widget/GeneratedIta1Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedios1widget/GeneratedIOs1Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedlangwidget/GeneratedLangWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedsceltapercorsowidget/GeneratedSceltaPercorsoWidget.dart';
import 'package:flutterapp/figmaflut1app/generateditinerarychoicewidget/GeneratedItineraryChoiceWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedinitialpagewidget/GeneratedInitialpageWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedita2widget/GeneratedIta2Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedita3widget/GeneratedIta3Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedita4widget/GeneratedIta4Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedita6widget/GeneratedIta6Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedita7widget/GeneratedIta7Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedita9widget/GeneratedIta9Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedita8widget/GeneratedIta8Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedita10widget/GeneratedIta10Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedita11widget/GeneratedIta11Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedita12widget/GeneratedIta12Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedita13widget/GeneratedIta13Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedita14widget/GeneratedIta14Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedita15widget/GeneratedIta15Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedriepilogowidget2/GeneratedRiepilogoWidget2.dart';
import 'package:flutterapp/figmaflut1app/generatedr1widget/GeneratedR1Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedr2widget/GeneratedR2Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedr3widget/GeneratedR3Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedita5widget/GeneratedIta5Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng1widget/GeneratedEng1Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng2widget/GeneratedEng2Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng3widget/GeneratedEng3Widget.dart';
import 'package:flutterapp/figmaflut1app/generateds3widget/GeneratedS3Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng4widget/GeneratedEng4Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng6widget/GeneratedEng6Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng7widget/GeneratedEng7Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng9widget/GeneratedEng9Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng8widget/GeneratedEng8Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng10widget/GeneratedEng10Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng11widget/GeneratedEng11Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng12widget/GeneratedEng12Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng13widget/GeneratedEng13Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng14widget/GeneratedEng14Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng15widget/GeneratedEng15Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedsummarywidget1/GeneratedSummaryWidget1.dart';
import 'package:flutterapp/figmaflut1app/generateds14widget/GeneratedS14Widget.dart';
import 'package:flutterapp/figmaflut1app/generateds12widget/GeneratedS12Widget.dart';
import 'package:flutterapp/figmaflut1app/generateds6widget/GeneratedS6Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeng5widget/GeneratedEng5Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedr4widget/GeneratedR4Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedr5widget/GeneratedR5Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedr6widget/GeneratedR6Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedr7widget/GeneratedR7Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedr8widget/GeneratedR8Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedr9widget/GeneratedR9Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedriepilogowidget3/GeneratedRiepilogoWidget3.dart';
import 'package:flutterapp/figmaflut1app/generatedriepilogowidget4/GeneratedRiepilogoWidget4.dart';
import 'package:flutterapp/figmaflut1app/generatedr14widget/GeneratedR14Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedr12widget/GeneratedR12Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedr13widget/GeneratedR13Widget.dart';
import 'package:flutterapp/figmaflut1app/generateds1widget/GeneratedS1Widget.dart';
import 'package:flutterapp/figmaflut1app/generateds2widget/GeneratedS2Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedsummarywidget2/GeneratedSummaryWidget2.dart';
import 'package:flutterapp/figmaflut1app/generatedsummarywidget3/GeneratedSummaryWidget3.dart';
import 'package:flutterapp/figmaflut1app/generateds7widget/GeneratedS7Widget.dart';
import 'package:flutterapp/figmaflut1app/generateds8widget/GeneratedS8Widget.dart';
import 'package:flutterapp/figmaflut1app/generateds9widget/GeneratedS9Widget.dart';
import 'package:flutterapp/figmaflut1app/generateds10widget/GeneratedS10Widget.dart';
import 'package:flutterapp/figmaflut1app/generateds11widget/GeneratedS11Widget.dart';
import 'package:flutterapp/figmaflut1app/generateds13widget/GeneratedS13Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedios2widget/GeneratedIOs2Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedios3widget/GeneratedIOs3Widget.dart';
import 'package:flutterapp/figmaflut1app/generatediosrwidget/GeneratedIOsRWidget.dart';
import 'package:flutterapp/figmaflut1app/generatediosrwidget1/GeneratedIOsRWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatediosrwidget2/GeneratedIOsRWidget2.dart';
import 'package:flutterapp/figmaflut1app/generatedeos1widget/GeneratedEOs1Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeos2widget/GeneratedEOs2Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeos3widget/GeneratedEOs3Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedeosswidget/GeneratedEOsSWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedeosswidget1/GeneratedEOsSWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedeosswidget2/GeneratedEOsSWidget2.dart';
import 'package:flutterapp/figmaflut1app/generatedis1widget/GeneratedIS1Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedis2widget/GeneratedIS2Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedis4widget/GeneratedIS4Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedis3widget/GeneratedIS3Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedisrwidget/GeneratedISRWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedisrwidget1/GeneratedISRWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedisrwidget2/GeneratedISRWidget2.dart';
import 'package:flutterapp/figmaflut1app/generatedis5widget/GeneratedIS5Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedarrivatiacrestperfavoreconsideratecompletareilsondaggio1/GeneratedArrivatiaCrestPerfavoreconsideratecompletareilsondaggio1.dart';
import 'package:flutterapp/figmaflut1app/generatedisrwidget3/GeneratedISRWidget3.dart';
import 'package:flutterapp/figmaflut1app/generatedisrwidget4/GeneratedISRWidget4.dart';
import 'package:flutterapp/figmaflut1app/generatedes1widget/GeneratedES1Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedes2widget/GeneratedES2Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedes4widget/GeneratedES4Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedes3widget/GeneratedES3Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedesrwidget/GeneratedESRWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedesrwidget1/GeneratedESRWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedesrwidget2/GeneratedESRWidget2.dart';
import 'package:flutterapp/figmaflut1app/generatedes5widget/GeneratedES5Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedyouhavearrivedatcrestpleaseconsiderdoingthesurveyhttpsf/GeneratedYouhavearrivedatCrestPleaseconsiderdoingthesurveyhttpsf.dart';
import 'package:flutterapp/figmaflut1app/generatedesrwidget3/GeneratedESRWidget3.dart';
import 'package:flutterapp/figmaflut1app/generatedesrwidget4/GeneratedESRWidget4.dart';
import 'package:flutterapp/figmaflut1app/generatedaltezzacrest1979maltezzaostafamassima2427mperfavorecons7/GeneratedAltezzaCrest1979mAltezzaOstafamassima2427mPerfavorecons7.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle16widget/GeneratedRectangle16Widget.dart';
import 'package:flutterapp/figmaflut1app/generated17markupwidget/Generated17MarkupWidget.dart';
import 'package:flutterapp/figmaflut1app/generated17markupwidget1/Generated17MarkupWidget1.dart';
import 'package:flutterapp/figmaflut1app/generated15deviceswidget/Generated15DevicesWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/Generated14IconsWidget.dart';
import 'package:flutterapp/figmaflut1app/generated13loaderswidget/Generated13LoadersWidget.dart';
import 'package:flutterapp/figmaflut1app/generated11imagesshapeswidget/Generated11ImagesShapesWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedwhenrecordingwidget/GeneratedWhenRecordingWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedwhenrecordingwidget1/GeneratedWhenRecordingWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedplaycirclewidget2/GeneratedPlaycircleWidget2.dart';
import 'package:flutterapp/figmaflut1app/generatedhomewidget2/GeneratedHomeWidget2.dart';
import 'package:flutterapp/figmaflut1app/generatedhomemenuopenwidget/GeneratedHomemenuopenWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedflowlinesstraightwidget1/GeneratedFlowLinesStraightWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedflowlinesstraightwidget2/GeneratedFlowLinesStraightWidget2.dart';
import 'package:flutterapp/figmaflut1app/generatedwhenrecordingmenuclosedwidget/GeneratedWhenRecordingmenuclosedWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedstartplanning2widget/GeneratedStartPlanning2Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle30widget/GeneratedRectangle30Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedcherckkomootperendrecordingwidget/GeneratedCherckKomootperendrecordingWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle31widget/GeneratedRectangle31Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedserachbarsicomprimevieneresortmetteretastoexpandsuresor/GeneratedSerachbarsicomprimeVieneresortMetteretastoexpandsuresor.dart';
import 'package:flutterapp/figmaflut1app/generatedgroup25widget/GeneratedGroup25Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle36widget/GeneratedRectangle36Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedaddsidebarwithvickywidget/GeneratedAddsidebarwithVickyWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedstartplanningwidget/GeneratedStartPlanningWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedgroup12widget/GeneratedGroup12Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedflowlinesstraightwidget3/GeneratedFlowLinesStraightWidget3.dart';
import 'package:flutterapp/figmaflut1app/generatedplanswidget/GeneratedPlansWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedprofilewidget/GeneratedProfileWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedsettingswidget4/GeneratedSettingsWidget4.dart';
import 'package:flutterapp/figmaflut1app/generatedexploreresortswidget/GeneratedExploreResortsWidget.dart';
import 'package:flutterapp/figmaflut1app/generatediphonexwidget12/GeneratedIPhoneXWidget12.dart';
import 'package:flutterapp/figmaflut1app/generatedgetreadyforadayofskiingwithnohassleswidget/GeneratedGetreadyforadayofskiingwithnohasslesWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedlookaroundtheapptofindyourfavoriteresortwidget/GeneratedLookaroundtheapptofindyourfavoriteresortWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedcheckyouralltimestatsonskeezwidget/GeneratedCheckyouralltimestatsonSkeezWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle3widget/GeneratedRectangle3Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedvector1widget1/GeneratedVector1Widget1.dart';
import 'package:flutterapp/figmaflut1app/generatedhomewidget/GeneratedHOMEWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle4widget94/GeneratedRectangle4Widget94.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle5widget3/GeneratedRectangle5Widget3.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle6widget1/GeneratedRectangle6Widget1.dart';
import 'package:flutterapp/figmaflut1app/generatedstartwidget/GeneratedSTARTWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedprofilewidget1/GeneratedPROFILEWidget1.dart';
import 'package:flutterapp/figmaflut1app/generateddiscoverwidget/GeneratedDISCOVERWidget.dart';
import 'package:flutterapp/figmaflut1app/generatediphonexwidget13/GeneratedIPhoneXWidget13.dart';
import 'package:flutterapp/figmaflut1app/generatedvector2widget3/GeneratedVector2Widget3.dart';
import 'package:flutterapp/figmaflut1app/generatedskeezlogo1widget/GeneratedSkeezLogo1Widget.dart';
import 'package:flutterapp/figmaflut1app/generatediphonexwidget14/GeneratedIPhoneXWidget14.dart';
import 'package:flutterapp/figmaflut1app/generatedcheckyouralltimestatsonskeezwidget1/GeneratedCheckyouralltimestatsonSkeezWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle13widget73/GeneratedRectangle13Widget73.dart';
import 'package:flutterapp/figmaflut1app/generatedvector3widget7/GeneratedVector3Widget7.dart';
import 'package:flutterapp/figmaflut1app/generatedhomewidget1/GeneratedHOMEWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle14widget14/GeneratedRectangle14Widget14.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle17widget1/GeneratedRectangle17Widget1.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle16widget2/GeneratedRectangle16Widget2.dart';
import 'package:flutterapp/figmaflut1app/generatedplanwidget8/GeneratedPlanWidget8.dart';
import 'package:flutterapp/figmaflut1app/generatedprofilewidget2/GeneratedPROFILEWidget2.dart';
import 'package:flutterapp/figmaflut1app/generatedatobwidget/GeneratedAtoBWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedskeezlogo3widget/GeneratedSkeezLogo3Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedimage1widget/GeneratedImage1Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedalertcirclewidget1/GeneratedAlertcircleWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle11widget19/GeneratedRectangle11Widget19.dart';
import 'package:flutterapp/figmaflut1app/generatednameofresortwidget/GeneratedNameofResortWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle8widget27/GeneratedRectangle8Widget27.dart';
import 'package:flutterapp/figmaflut1app/generatedpicktheresortwidget/GeneratedPicktheResortWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedflowlinesarrowwidget1/GeneratedFlowLinesArrowWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedslidetogettonewresortwidget/GeneratedSlidetogettonewresortWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle7widget24/GeneratedRectangle7Widget24.dart';
import 'package:flutterapp/figmaflut1app/generatedskeezlogo2widget/GeneratedSkeezLogo2Widget.dart';
import 'package:flutterapp/figmaflut1app/generatedstartwidget1/GeneratedSTARTWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedellipse1widget5/GeneratedEllipse1Widget5.dart';
import 'package:flutterapp/figmaflut1app/generatedellipse2widget34/GeneratedEllipse2Widget34.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle18widget1/GeneratedRectangle18Widget1.dart';
import 'package:flutterapp/figmaflut1app/generatedrectangle19widget1/GeneratedRectangle19Widget1.dart';
import 'package:flutterapp/figmaflut1app/generatedunderherepreviousideadontlookatitfornowwidget/GeneratedUnderherepreviousideadontlookatitfornowWidget.dart';
import 'package:flutterapp/figmaflut1app/generatedwhenrecordingwidget2/GeneratedWhenRecordingWidget2.dart';
import 'package:flutterapp/figmaflut1app/generatedhomewidget3/GeneratedHomeWidget3.dart';
import 'package:flutterapp/figmaflut1app/generatedwhenrecordingmenuclosedwidget1/GeneratedWhenRecordingmenuclosedWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedstartplanningwidget1/GeneratedStartPlanningWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedplanswidget1/GeneratedPlansWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedexploreresortswidget1/GeneratedExploreResortsWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedprofilewidget1/GeneratedProfileWidget1.dart';
import 'package:flutterapp/figmaflut1app/generatedsettingswidget5/GeneratedSettingsWidget5.dart';

void main() {
  runApp(FigmaFlut1App());
}

class FigmaFlut1App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedInitialpageWidget',
      routes: {
        '/GeneratedIta1Widget': (context) => GeneratedIta1Widget(),
        '/GeneratedIOs1Widget': (context) => GeneratedIOs1Widget(),
        '/GeneratedLangWidget': (context) => GeneratedLangWidget(),
        '/GeneratedSceltaPercorsoWidget': (context) =>
            GeneratedSceltaPercorsoWidget(),
        '/GeneratedItineraryChoiceWidget': (context) =>
            GeneratedItineraryChoiceWidget(),
        '/GeneratedInitialpageWidget': (context) =>
            GeneratedInitialpageWidget(),
        '/GeneratedIta2Widget': (context) => GeneratedIta2Widget(),
        '/GeneratedIta3Widget': (context) => GeneratedIta3Widget(),
        '/GeneratedIta4Widget': (context) => GeneratedIta4Widget(),
        '/GeneratedIta6Widget': (context) => GeneratedIta6Widget(),
        '/GeneratedIta7Widget': (context) => GeneratedIta7Widget(),
        '/GeneratedIta9Widget': (context) => GeneratedIta9Widget(),
        '/GeneratedIta8Widget': (context) => GeneratedIta8Widget(),
        '/GeneratedIta10Widget': (context) => GeneratedIta10Widget(),
        '/GeneratedIta11Widget': (context) => GeneratedIta11Widget(),
        '/GeneratedIta12Widget': (context) => GeneratedIta12Widget(),
        '/GeneratedIta13Widget': (context) => GeneratedIta13Widget(),
        '/GeneratedIta14Widget': (context) => GeneratedIta14Widget(),
        '/GeneratedIta15Widget': (context) => GeneratedIta15Widget(),
        '/GeneratedRiepilogoWidget2': (context) => GeneratedRiepilogoWidget2(),
        '/GeneratedR1Widget': (context) => GeneratedR1Widget(),
        '/GeneratedR2Widget': (context) => GeneratedR2Widget(),
        '/GeneratedR3Widget': (context) => GeneratedR3Widget(),
        '/GeneratedIta5Widget': (context) => GeneratedIta5Widget(),
        '/GeneratedEng1Widget': (context) => GeneratedEng1Widget(),
        '/GeneratedEng2Widget': (context) => GeneratedEng2Widget(),
        '/GeneratedEng3Widget': (context) => GeneratedEng3Widget(),
        '/GeneratedS3Widget': (context) => GeneratedS3Widget(),
        '/GeneratedEng4Widget': (context) => GeneratedEng4Widget(),
        '/GeneratedEng6Widget': (context) => GeneratedEng6Widget(),
        '/GeneratedEng7Widget': (context) => GeneratedEng7Widget(),
        '/GeneratedEng9Widget': (context) => GeneratedEng9Widget(),
        '/GeneratedEng8Widget': (context) => GeneratedEng8Widget(),
        '/GeneratedEng10Widget': (context) => GeneratedEng10Widget(),
        '/GeneratedEng11Widget': (context) => GeneratedEng11Widget(),
        '/GeneratedEng12Widget': (context) => GeneratedEng12Widget(),
        '/GeneratedEng13Widget': (context) => GeneratedEng13Widget(),
        '/GeneratedEng14Widget': (context) => GeneratedEng14Widget(),
        '/GeneratedEng15Widget': (context) => GeneratedEng15Widget(),
        '/GeneratedSummaryWidget1': (context) => GeneratedSummaryWidget1(),
        '/GeneratedS14Widget': (context) => GeneratedS14Widget(),
        '/GeneratedS12Widget': (context) => GeneratedS12Widget(),
        '/GeneratedS6Widget': (context) => GeneratedS6Widget(),
        '/GeneratedEng5Widget': (context) => GeneratedEng5Widget(),
        '/GeneratedR4Widget': (context) => GeneratedR4Widget(),
        '/GeneratedR5Widget': (context) => GeneratedR5Widget(),
        '/GeneratedR6Widget': (context) => GeneratedR6Widget(),
        '/GeneratedR7Widget': (context) => GeneratedR7Widget(),
        '/GeneratedR8Widget': (context) => GeneratedR8Widget(),
        '/GeneratedR9Widget': (context) => GeneratedR9Widget(),
        '/GeneratedRiepilogoWidget3': (context) => GeneratedRiepilogoWidget3(),
        '/GeneratedRiepilogoWidget4': (context) => GeneratedRiepilogoWidget4(),
        '/GeneratedR14Widget': (context) => GeneratedR14Widget(),
        '/GeneratedR12Widget': (context) => GeneratedR12Widget(),
        '/GeneratedR13Widget': (context) => GeneratedR13Widget(),
        '/GeneratedS1Widget': (context) => GeneratedS1Widget(),
        '/GeneratedS2Widget': (context) => GeneratedS2Widget(),
        '/GeneratedSummaryWidget2': (context) => GeneratedSummaryWidget2(),
        '/GeneratedSummaryWidget3': (context) => GeneratedSummaryWidget3(),
        '/GeneratedS7Widget': (context) => GeneratedS7Widget(),
        '/GeneratedS8Widget': (context) => GeneratedS8Widget(),
        '/GeneratedS9Widget': (context) => GeneratedS9Widget(),
        '/GeneratedS10Widget': (context) => GeneratedS10Widget(),
        '/GeneratedS11Widget': (context) => GeneratedS11Widget(),
        '/GeneratedS13Widget': (context) => GeneratedS13Widget(),
        '/GeneratedIOs2Widget': (context) => GeneratedIOs2Widget(),
        '/GeneratedIOs3Widget': (context) => GeneratedIOs3Widget(),
        '/GeneratedIOsRWidget': (context) => GeneratedIOsRWidget(),
        '/GeneratedIOsRWidget1': (context) => GeneratedIOsRWidget1(),
        '/GeneratedIOsRWidget2': (context) => GeneratedIOsRWidget2(),
        '/GeneratedEOs1Widget': (context) => GeneratedEOs1Widget(),
        '/GeneratedEOs2Widget': (context) => GeneratedEOs2Widget(),
        '/GeneratedEOs3Widget': (context) => GeneratedEOs3Widget(),
        '/GeneratedEOsSWidget': (context) => GeneratedEOsSWidget(),
        '/GeneratedEOsSWidget1': (context) => GeneratedEOsSWidget1(),
        '/GeneratedEOsSWidget2': (context) => GeneratedEOsSWidget2(),
        '/GeneratedIS1Widget': (context) => GeneratedIS1Widget(),
        '/GeneratedIS2Widget': (context) => GeneratedIS2Widget(),
        '/GeneratedIS4Widget': (context) => GeneratedIS4Widget(),
        '/GeneratedIS3Widget': (context) => GeneratedIS3Widget(),
        '/GeneratedISRWidget': (context) => GeneratedISRWidget(),
        '/GeneratedISRWidget1': (context) => GeneratedISRWidget1(),
        '/GeneratedISRWidget2': (context) => GeneratedISRWidget2(),
        '/GeneratedIS5Widget': (context) => GeneratedIS5Widget(),
        '/GeneratedArrivatiaCrestPerfavoreconsideratecompletareilsondaggio1':
            (context) =>
                GeneratedArrivatiaCrestPerfavoreconsideratecompletareilsondaggio1(),
        '/GeneratedISRWidget3': (context) => GeneratedISRWidget3(),
        '/GeneratedISRWidget4': (context) => GeneratedISRWidget4(),
        '/GeneratedES1Widget': (context) => GeneratedES1Widget(),
        '/GeneratedES2Widget': (context) => GeneratedES2Widget(),
        '/GeneratedES4Widget': (context) => GeneratedES4Widget(),
        '/GeneratedES3Widget': (context) => GeneratedES3Widget(),
        '/GeneratedESRWidget': (context) => GeneratedESRWidget(),
        '/GeneratedESRWidget1': (context) => GeneratedESRWidget1(),
        '/GeneratedESRWidget2': (context) => GeneratedESRWidget2(),
        '/GeneratedES5Widget': (context) => GeneratedES5Widget(),
        '/GeneratedYouhavearrivedatCrestPleaseconsiderdoingthesurveyhttpsf':
            (context) =>
                GeneratedYouhavearrivedatCrestPleaseconsiderdoingthesurveyhttpsf(),
        '/GeneratedESRWidget3': (context) => GeneratedESRWidget3(),
        '/GeneratedESRWidget4': (context) => GeneratedESRWidget4(),
        '/GeneratedAltezzaCrest1979mAltezzaOstafamassima2427mPerfavorecons7':
            (context) =>
                GeneratedAltezzaCrest1979mAltezzaOstafamassima2427mPerfavorecons7(),
        '/GeneratedRectangle16Widget': (context) =>
            GeneratedRectangle16Widget(),
        '/Generated17MarkupWidget': (context) => Generated17MarkupWidget(),
        '/Generated17MarkupWidget1': (context) => Generated17MarkupWidget1(),
        '/Generated15DevicesWidget': (context) => Generated15DevicesWidget(),
        '/Generated14IconsWidget': (context) => Generated14IconsWidget(),
        '/Generated13LoadersWidget': (context) => Generated13LoadersWidget(),
        '/Generated11ImagesShapesWidget': (context) =>
            Generated11ImagesShapesWidget(),
        '/GeneratedWhenRecordingWidget': (context) =>
            GeneratedWhenRecordingWidget(),
        '/GeneratedWhenRecordingWidget1': (context) =>
            GeneratedWhenRecordingWidget1(),
        '/GeneratedPlaycircleWidget2': (context) =>
            GeneratedPlaycircleWidget2(),
        '/GeneratedHomeWidget2': (context) => GeneratedHomeWidget2(),
        '/GeneratedHomemenuopenWidget': (context) =>
            GeneratedHomemenuopenWidget(),
        '/GeneratedFlowLinesStraightWidget1': (context) =>
            GeneratedFlowLinesStraightWidget1(),
        '/GeneratedFlowLinesStraightWidget2': (context) =>
            GeneratedFlowLinesStraightWidget2(),
        '/GeneratedWhenRecordingmenuclosedWidget': (context) =>
            GeneratedWhenRecordingmenuclosedWidget(),
        '/GeneratedStartPlanning2Widget': (context) =>
            GeneratedStartPlanning2Widget(),
        '/GeneratedRectangle30Widget': (context) =>
            GeneratedRectangle30Widget(),
        '/GeneratedCherckKomootperendrecordingWidget': (context) =>
            GeneratedCherckKomootperendrecordingWidget(),
        '/GeneratedRectangle31Widget': (context) =>
            GeneratedRectangle31Widget(),
        '/GeneratedSerachbarsicomprimeVieneresortMetteretastoexpandsuresor':
            (context) =>
                GeneratedSerachbarsicomprimeVieneresortMetteretastoexpandsuresor(),
        '/GeneratedGroup25Widget': (context) => GeneratedGroup25Widget(),
        '/GeneratedRectangle36Widget': (context) =>
            GeneratedRectangle36Widget(),
        '/GeneratedAddsidebarwithVickyWidget': (context) =>
            GeneratedAddsidebarwithVickyWidget(),
        '/GeneratedStartPlanningWidget': (context) =>
            GeneratedStartPlanningWidget(),
        '/GeneratedGroup12Widget': (context) => GeneratedGroup12Widget(),
        '/GeneratedFlowLinesStraightWidget3': (context) =>
            GeneratedFlowLinesStraightWidget3(),
        '/GeneratedPlansWidget': (context) => GeneratedPlansWidget(),
        '/GeneratedProfileWidget': (context) => GeneratedProfileWidget(),
        '/GeneratedSettingsWidget4': (context) => GeneratedSettingsWidget4(),
        '/GeneratedExploreResortsWidget': (context) =>
            GeneratedExploreResortsWidget(),
        '/GeneratedIPhoneXWidget12': (context) => GeneratedIPhoneXWidget12(),
        '/GeneratedGetreadyforadayofskiingwithnohasslesWidget': (context) =>
            GeneratedGetreadyforadayofskiingwithnohasslesWidget(),
        '/GeneratedLookaroundtheapptofindyourfavoriteresortWidget': (context) =>
            GeneratedLookaroundtheapptofindyourfavoriteresortWidget(),
        '/GeneratedCheckyouralltimestatsonSkeezWidget': (context) =>
            GeneratedCheckyouralltimestatsonSkeezWidget(),
        '/GeneratedRectangle3Widget': (context) => GeneratedRectangle3Widget(),
        '/GeneratedVector1Widget1': (context) => GeneratedVector1Widget1(),
        '/GeneratedHOMEWidget': (context) => GeneratedHOMEWidget(),
        '/GeneratedRectangle4Widget94': (context) =>
            GeneratedRectangle4Widget94(),
        '/GeneratedRectangle5Widget3': (context) =>
            GeneratedRectangle5Widget3(),
        '/GeneratedRectangle6Widget1': (context) =>
            GeneratedRectangle6Widget1(),
        '/GeneratedSTARTWidget': (context) => GeneratedSTARTWidget(),
        '/GeneratedPROFILEWidget1': (context) => GeneratedPROFILEWidget1(),
        '/GeneratedDISCOVERWidget': (context) => GeneratedDISCOVERWidget(),
        '/GeneratedIPhoneXWidget13': (context) => GeneratedIPhoneXWidget13(),
        '/GeneratedVector2Widget3': (context) => GeneratedVector2Widget3(),
        '/GeneratedSkeezLogo1Widget': (context) => GeneratedSkeezLogo1Widget(),
        '/GeneratedIPhoneXWidget14': (context) => GeneratedIPhoneXWidget14(),
        '/GeneratedCheckyouralltimestatsonSkeezWidget1': (context) =>
            GeneratedCheckyouralltimestatsonSkeezWidget1(),
        '/GeneratedRectangle13Widget73': (context) =>
            GeneratedRectangle13Widget73(),
        '/GeneratedVector3Widget7': (context) => GeneratedVector3Widget7(),
        '/GeneratedHOMEWidget1': (context) => GeneratedHOMEWidget1(),
        '/GeneratedRectangle14Widget14': (context) =>
            GeneratedRectangle14Widget14(),
        '/GeneratedRectangle17Widget1': (context) =>
            GeneratedRectangle17Widget1(),
        '/GeneratedRectangle16Widget2': (context) =>
            GeneratedRectangle16Widget2(),
        '/GeneratedPlanWidget8': (context) => GeneratedPlanWidget8(),
        '/GeneratedPROFILEWidget2': (context) => GeneratedPROFILEWidget2(),
        '/GeneratedAtoBWidget': (context) => GeneratedAtoBWidget(),
        '/GeneratedSkeezLogo3Widget': (context) => GeneratedSkeezLogo3Widget(),
        '/GeneratedImage1Widget': (context) => GeneratedImage1Widget(),
        '/GeneratedAlertcircleWidget1': (context) =>
            GeneratedAlertcircleWidget1(),
        '/GeneratedRectangle11Widget19': (context) =>
            GeneratedRectangle11Widget19(),
        '/GeneratedNameofResortWidget': (context) =>
            GeneratedNameofResortWidget(),
        '/GeneratedRectangle8Widget27': (context) =>
            GeneratedRectangle8Widget27(),
        '/GeneratedPicktheResortWidget': (context) =>
            GeneratedPicktheResortWidget(),
        '/GeneratedFlowLinesArrowWidget1': (context) =>
            GeneratedFlowLinesArrowWidget1(),
        '/GeneratedSlidetogettonewresortWidget': (context) =>
            GeneratedSlidetogettonewresortWidget(),
        '/GeneratedRectangle7Widget24': (context) =>
            GeneratedRectangle7Widget24(),
        '/GeneratedSkeezLogo2Widget': (context) => GeneratedSkeezLogo2Widget(),
        '/GeneratedSTARTWidget1': (context) => GeneratedSTARTWidget1(),
        '/GeneratedEllipse1Widget5': (context) => GeneratedEllipse1Widget5(),
        '/GeneratedEllipse2Widget34': (context) => GeneratedEllipse2Widget34(),
        '/GeneratedRectangle18Widget1': (context) =>
            GeneratedRectangle18Widget1(),
        '/GeneratedRectangle19Widget1': (context) =>
            GeneratedRectangle19Widget1(),
        '/GeneratedUnderherepreviousideadontlookatitfornowWidget': (context) =>
            GeneratedUnderherepreviousideadontlookatitfornowWidget(),
        '/GeneratedWhenRecordingWidget2': (context) =>
            GeneratedWhenRecordingWidget2(),
        '/GeneratedHomeWidget3': (context) => GeneratedHomeWidget3(),
        '/GeneratedWhenRecordingmenuclosedWidget1': (context) =>
            GeneratedWhenRecordingmenuclosedWidget1(),
        '/GeneratedStartPlanningWidget1': (context) =>
            GeneratedStartPlanningWidget1(),
        '/GeneratedPlansWidget1': (context) => GeneratedPlansWidget1(),
        '/GeneratedExploreResortsWidget1': (context) =>
            GeneratedExploreResortsWidget1(),
        '/GeneratedProfileWidget1': (context) => GeneratedProfileWidget1(),
        '/GeneratedSettingsWidget5': (context) => GeneratedSettingsWidget5(),
      },
    );
  }
}
