import 'package:flutter/material.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedLinkedinWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMailWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedChevrondownWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedScissorsWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCodeWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedUploadcloudWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedShieldWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedShieldoffWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedGitlabWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMorehorizontalWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPocketWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedXoctagonWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedArrowrightWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedEdit2Widget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedAirplayWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPhoneoutgoingWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedKeyWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBookopenWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCornerrightupWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedArrowdownWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMaximizeWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCornerupleftWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedArrowdownrightWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedAligncenterWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPaperclipWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedArrowuprightWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedAlignrightWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedVideooffWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBoxWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTrash2Widget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedEyeWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedShare2Widget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCameraoffWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMessagesquareWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedChecksquareWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedWifioffWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPausecircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedUserplusWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedZoomoutWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedChevronsupWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedArrowrightcircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMenuWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMaximize2Widget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCoffeeWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedHeadphonesWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFeatherWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedNavigationWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedVoicemailWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTargetWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFastforwardWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCalendarWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCornerleftupWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedAlignjustifyWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMinimizeWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTrendingupWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTrendingdownWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFigmaWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedHashWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedXcircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedChevronupWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedDollarsignWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedXWidget4.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedArrowupWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedServerWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedShareWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPrinterWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedListWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedUploadWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSkipforwardWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSendWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFlagWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedAlerttriangleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMusicWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedHarddriveWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMinusWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFolderminusWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedGiftWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedDropletWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPhoneforwardedWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedGitcommitWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSidebarWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSearchWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedUmbrellaWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBelloffWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedWatchWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedClipboardWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPentoolWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedLockWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedClockWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedDiscWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedZapoffWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTwitterWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFileplusWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedUtilitiesPageHeaderWidget4.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedThumbsdownWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCloudlightningWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSunWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPhonemissedWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedLoginWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFrownWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedArrowupleftWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedXsquareWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMessagecircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTruckWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSquareWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBriefcaseWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFileminusWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCameraWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedRefreshccwWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMinuscircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCheckWidget9.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSlidersWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedArrowleftcircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedVolume2Widget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCloudsnowWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedArrowupcircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedGitbranchWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedEdit3Widget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSmartphoneWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedLogoutWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCornerrightdownWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSlashWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedVolumeWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedArchiveWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedHeartWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMoonWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedChevronrightWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMonitorWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSettingsWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCorneruprightWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBoldWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFilterWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedVideoWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCornerdownrightWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMoveWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedOctagonWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCpuWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedLoaderWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPowerWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedAlertoctagonWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedAlignleftWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMicoffWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPlaycircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedChevronsleftWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedThumbsupWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBackgroundWidget7.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedHomeWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPlayWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTypeWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedInfoWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCodesandboxWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedDownloadcloudWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedLink2Widget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedHelpcircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedRadioWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBatteryWidget6.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFolderWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedImageWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPauseWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTriangleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMinimize2Widget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPiechartWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSmileWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSkipbackWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedDownloadWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedEyeoffWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedWifiWidget4.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTvWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedYoutubeWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPhoneoffWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFiletextWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMehWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCrosshairWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPlusWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedRotateccwWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCloudWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedStopcircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSaveWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCompassWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPercentWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedZapWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedLayoutWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedRssWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCreditcardWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSunsetWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedClouddrizzleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMicWidget4.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedUserWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBarchart2Widget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBookmarkWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFolderplusWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedRewindWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedGithubWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTerminalWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCopyWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedShoppingbagWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMappinWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedGridWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedShuffleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedExternallinkWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedChevronsrightWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedThermometerWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedWindWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCloudoffWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMinussquareWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedRotatecwWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedArrowdowncircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPhoneincomingWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCornerdownleftWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCastWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedAwardWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedEditWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBoxWidget1.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSlackWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedAnchorWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedRepeatWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedInboxWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCommandWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBarchartWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedDeleteWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedShoppingcartWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCropWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedChevronsdownWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedRefreshcwWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedItalicWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedInstagramWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCornerleftdownWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFileWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedUnderlineWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedLinkWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedNavigation2Widget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTagWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBluetoothWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedVolume1Widget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPhoneWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedActivityWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedGroup2Widget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedArrowleftWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedChromeWidget1.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPlussquareWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedApertureWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedUserxWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTogglerightWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTrashWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMapWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedDatabaseWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedToggleleftWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPluscircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBellWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedAlertcircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFilmWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedToolWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPhonecallWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedAtsignWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBookWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedUnlockWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedGitmergeWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCodepenWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedGlobeWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedUsercheckWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMousepointerWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFramerWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedChevronleftWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSunriseWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedColumnsWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCheckcircleWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedBatterychargingWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedCloudrainWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedArrowdownleftWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedStarWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTabletWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedHexagonWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedTrelloWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedPackageWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedUserminusWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedLifebuoyWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedVolumexWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedGitpullrequestWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedLayersWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedMoreverticalWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedZoominWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedUsersWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedFacebookWidget.dart';
import 'package:flutterapp/figmaflut1app/generated14iconswidget/generated/GeneratedSpeakerWidget.dart';

/* Frame 14 Icons
    Autogenerated by FlutLab FTF Generator
  */
class Generated14IconsWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Material(
        child: ClipRRect(
      borderRadius: BorderRadius.zero,
      child: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
        return SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Container(
              height: 1428.0,
              child: Stack(children: [
                Container(
                    width: constraints.maxWidth,
                    child: Container(
                      width: 1000.0,
                      height: 1428.0,
                      child: Stack(
                          fit: StackFit.expand,
                          alignment: Alignment.center,
                          overflow: Overflow.visible,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.zero,
                              child: Container(
                                color: Color.fromARGB(255, 224, 234, 255),
                              ),
                            ),
                            Positioned(
                              left: 0.0,
                              top: 0.0,
                              right: null,
                              bottom: null,
                              width: 1000.0,
                              height: 1428.0,
                              child: GeneratedBackgroundWidget7(),
                            ),
                            Positioned(
                              left: 0.0,
                              top: 0.0,
                              right: null,
                              bottom: null,
                              width: 1000.0,
                              height: 180.0,
                              child: GeneratedUtilitiesPageHeaderWidget4(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 288.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedActivityWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 288.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedAirplayWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 288.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedAlertcircleWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 288.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedAlertoctagonWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 288.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedAlerttriangleWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 288.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedAligncenterWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 288.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedAlignjustifyWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 288.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedAlignleftWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 288.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedAlignrightWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 288.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedAnchorWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 288.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedApertureWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 288.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedArchiveWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 324.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedArrowdowncircleWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 324.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedArrowdownleftWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 324.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedArrowdownrightWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 324.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedArrowdownWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 324.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedArrowleftcircleWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 324.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedArrowleftWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 324.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedArrowrightcircleWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 324.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedArrowrightWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 324.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedArrowupcircleWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 324.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedArrowupleftWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 324.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedArrowuprightWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 324.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedArrowupWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 360.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedAtsignWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 360.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedAwardWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 360.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBarchart2Widget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 360.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBarchartWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 360.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBatterychargingWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 360.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBatteryWidget6(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 360.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBelloffWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 360.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBellWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 360.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBluetoothWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 360.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBoldWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 360.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBookopenWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 360.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBookWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 396.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBookmarkWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 396.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBoxWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 396.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBriefcaseWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 396.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCalendarWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 396.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCameraoffWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 396.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCameraWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 396.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCastWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 396.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCheckcircleWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 396.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedChecksquareWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 396.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCheckWidget9(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 396.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedChevrondownWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 432.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedChevronleftWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 432.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedChevronrightWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 432.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedChevronupWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 432.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedChevronsdownWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 432.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedChevronsleftWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 432.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedChevronsrightWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 432.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedChevronsupWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 432.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedChromeWidget1(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 432.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCircleWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 432.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedClipboardWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 432.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedClockWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 468.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedClouddrizzleWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 468.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCloudlightningWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 468.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCloudoffWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 468.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCloudrainWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 468.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCloudsnowWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 432.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCloudWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 468.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCodeWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 468.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCodepenWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 468.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCoffeeWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 468.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCommandWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 468.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCompassWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 504.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCopyWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 504.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCornerdownleftWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 504.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCornerdownrightWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 504.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCornerleftdownWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 504.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCornerleftupWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 504.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCornerrightdownWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 504.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCornerrightupWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 504.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCornerupleftWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 504.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCorneruprightWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 504.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCpuWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 504.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCreditcardWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 504.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCropWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 540.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCrosshairWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 540.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedDatabaseWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 540.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedDeleteWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 540.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedDiscWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 540.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedDollarsignWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 540.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedDownloadcloudWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 540.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedDownloadWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 540.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedDropletWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 540.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedEdit2Widget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 540.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedEdit3Widget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 540.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedEditWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 540.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedExternallinkWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 576.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedEyeoffWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 576.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedEyeWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 576.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFacebookWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 576.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFastforwardWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 576.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFeatherWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 576.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFileminusWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 576.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFileplusWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 576.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFiletextWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 576.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFileWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 576.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFilmWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 576.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFilterWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 612.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFlagWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 612.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFolderminusWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 612.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFolderplusWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 612.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFolderWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 612.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFrownWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 612.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedGiftWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 612.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedGitbranchWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 612.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedGitcommitWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 612.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedGitmergeWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 612.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedGitpullrequestWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 612.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedGithubWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 648.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedGitlabWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 648.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedGlobeWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 648.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedGridWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 648.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedHarddriveWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 648.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedHashWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 648.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedHeadphonesWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 648.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedHeartWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 648.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedHelpcircleWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 648.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedHomeWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 648.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedImageWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 648.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedInboxWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 684.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedInfoWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 684.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedInstagramWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 684.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedItalicWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 684.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedKeyWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 684.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedLayersWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 684.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedLayoutWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 684.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedLifebuoyWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 684.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedLink2Widget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 684.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedLinkWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 684.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedLinkedinWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 684.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedListWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 684.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedLoaderWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 720.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedLockWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 720.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedLoginWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 720.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedLogoutWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 720.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMailWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 720.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMappinWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 720.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMapWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 720.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMaximize2Widget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 720.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMaximizeWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 720.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMehWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 720.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMenuWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 720.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMessagecircleWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 720.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMessagesquareWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 756.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMicoffWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 756.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMicWidget4(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 756.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMinimize2Widget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 756.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMinimizeWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 756.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMinuscircleWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 756.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMinussquareWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 756.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMinusWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 756.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMonitorWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 756.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMoonWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 756.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMorehorizontalWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 756.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMoreverticalWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 756.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMousepointerWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 792.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMoveWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 792.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedMusicWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 792.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedNavigation2Widget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 792.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedNavigationWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 792.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedOctagonWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 792.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPackageWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 792.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPaperclipWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 792.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPausecircleWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 792.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPauseWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 792.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPentoolWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 792.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPercentWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 828.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPhonecallWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 828.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPhoneforwardedWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 828.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPhoneincomingWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 828.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPhonemissedWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 828.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPhoneoffWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 828.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPhoneoutgoingWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 792.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPhoneWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 828.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPiechartWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 828.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPlaycircleWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 828.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPlayWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 828.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPluscircleWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 828.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPlussquareWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 828.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPlusWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 864.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPocketWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 864.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPowerWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 864.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedPrinterWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 864.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedRadioWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 864.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedRefreshccwWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 864.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedRefreshcwWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 864.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedRepeatWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 864.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedRewindWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 864.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedRotateccwWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 864.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedRotatecwWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 864.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedRssWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 864.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSaveWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 900.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedScissorsWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 900.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSearchWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 900.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSendWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 900.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedServerWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 900.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSettingsWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 900.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedShare2Widget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 900.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedShareWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 900.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedShieldoffWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 900.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedShieldWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 900.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedShoppingbagWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 900.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedShoppingcartWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 900.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedShuffleWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 936.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSidebarWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 936.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSkipbackWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 936.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSkipforwardWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 936.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSlackWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 936.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSlashWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 936.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSlidersWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 936.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSmartphoneWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 936.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSmileWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 936.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSpeakerWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 936.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSquareWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 936.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedStarWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 936.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedStopcircleWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 972.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSunWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 972.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSunriseWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 972.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedSunsetWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 972.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTabletWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 972.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTagWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 972.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTargetWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 972.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTerminalWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 972.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedThermometerWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 972.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedThumbsdownWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 972.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedThumbsupWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 972.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedToggleleftWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 972.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTogglerightWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 1008.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTrash2Widget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 1008.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTrashWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 1008.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTrelloWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 1008.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTrendingdownWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 1008.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTrendingupWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 1008.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTriangleWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 1008.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTruckWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 1008.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTvWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 1008.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTwitterWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 1008.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedTypeWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 1008.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedUmbrellaWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 1044.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedUnderlineWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 1044.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedUnlockWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 1044.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedUploadcloudWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 1044.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedUploadWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 1044.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedUsercheckWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 1044.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedUserminusWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 1044.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedUserplusWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 1044.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedUserxWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 1044.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedUserWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 1044.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedUsersWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 1044.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedVideooffWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 1044.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedVideoWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 1080.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedVoicemailWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 1080.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedVolume1Widget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 1080.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedVolume2Widget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 1080.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedVolumexWidget(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 1080.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedVolumeWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 1080.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedWatchWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 1080.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedWifioffWidget(),
                            ),
                            Positioned(
                              left: 506.0,
                              top: 1080.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedWifiWidget4(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 1080.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedWindWidget(),
                            ),
                            Positioned(
                              left: 650.0,
                              top: 1080.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedXcircleWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 1116.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedXsquareWidget(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 1080.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedXWidget4(),
                            ),
                            Positioned(
                              left: 326.0,
                              top: 1116.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedYoutubeWidget(),
                            ),
                            Positioned(
                              left: 398.0,
                              top: 1116.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedZapoffWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 1116.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedZapWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 1116.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedZoominWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 1116.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedZoomoutWidget(),
                            ),
                            Positioned(
                              left: 290.0,
                              top: 1008.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedToolWidget(),
                            ),
                            Positioned(
                              left: 434.0,
                              top: 612.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFramerWidget(),
                            ),
                            Positioned(
                              left: 542.0,
                              top: 468.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedCodesandboxWidget(),
                            ),
                            Positioned(
                              left: 578.0,
                              top: 648.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedHexagonWidget(),
                            ),
                            Positioned(
                              left: 362.0,
                              top: 396.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedBoxWidget1(),
                            ),
                            Positioned(
                              left: 614.0,
                              top: 468.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedColumnsWidget(),
                            ),
                            Positioned(
                              left: 686.0,
                              top: 1080.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedXoctagonWidget(),
                            ),
                            Positioned(
                              left: 470.0,
                              top: 576.0,
                              right: null,
                              bottom: null,
                              width: 24.0,
                              height: 24.0,
                              child: GeneratedFigmaWidget(),
                            ),
                            Positioned(
                              left: 530.0,
                              top: 1119.0,
                              right: null,
                              bottom: null,
                              width: 52.0,
                              height: 52.0,
                              child: GeneratedGroup2Widget(),
                            )
                          ]),
                    ))
              ])),
        );
      }),
    ));
  }
}
